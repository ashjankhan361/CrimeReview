from flask import Flask
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.schedulers.blocking import BlockingScheduler
from scraperbsmongo import getDetails
# Schedule Library imported
import schedule
import time
import datetime

def some_job():
     getDetails()
     x = datetime.datetime.now()
     print("Scrapping completed at.. " +x.strftime("%c") )
    
scheduler = BlockingScheduler()
job=scheduler.add_job(some_job, 'interval', seconds=10)
scheduler.start()

