CREATE DATABASE IF NOT exists glogin DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
use glogin;

CREATE TABLE IF NOT exists accounts (
email varchar(150) NOT NULL,
password varchar(255) NOT NULL,
PRIMARY KEY(email)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;


