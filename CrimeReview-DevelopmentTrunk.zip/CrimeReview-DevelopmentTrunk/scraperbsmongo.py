import requests
from bs4 import BeautifulSoup
import time
import json
import csv
import pandas as pd
import sys, getopt, pprint
import pymongo
from pymongo import MongoClient
def getDetails():

    url ='http://www.fwpd.org/activity-log'
    headers= {'User-Agent': 'Chrome/59.0.3071.115'}
    response = requests.get(url)
    response.status_code
    response.content
    soup = BeautifulSoup(response.content, 'html.parser')
    stat = soup.find_all('table', class_ = 'content' )

    stat = stat[0]
    print("getDetails() called at")
    headerStr = 'Date,Year,Time,Nature,Address,Location,Control#'
    header= ["Date","Year","Time","Nature", "Address","Location","Control#"]
    for row in stat.find_all('tr'):
        for cell in row.find_all('td'):
            print(cell.text)
    with open ('crimedata5.csv', 'w') as r:
        r.write(headerStr)
        for row in stat.find_all('tr'):
            for cell in row.find_all('td'):
                r.write(cell.text.strip()+",")
            r.write('\n')

    #CSV to JSON Conversion
    conn = pymongo.MongoClient("mongodb://localhost:27017/")
    db = conn.dbproj #dbproj is my database
    col = db.crimedata1
    csvfile = open('crimedata5.csv', 'r')
    reader = csv.DictReader( csvfile )
    db.segment.drop()
    exclude = ('id',)

    for each in reader:
        row={}
        for field in header:
            row[field]=each[field]

        db.crimedata1.insert_one(row)